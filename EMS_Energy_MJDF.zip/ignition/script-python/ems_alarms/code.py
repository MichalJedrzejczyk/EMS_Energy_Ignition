def getActiveAlarmCount():
    alarms = system.alarm.queryStatus(
        state=["ActiveUnacked", "ActiveAcked"]
    )
    return len(alarms)