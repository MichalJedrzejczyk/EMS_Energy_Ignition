def _read(path, default=0):
    try:
        qv = system.tag.readBlocking([path])[0]
        if qv.value is None:
            return default
        return qv.value
    except:
        return default


def _to_float(value, default=1.0):
    try:
        return float(value)
    except:
        return default


def getCurrentPower(locationFactor=1.0, meterFactor=1.0):
    current = float(_read("[default]EMS/Energy/Production/Meter_01/Current", 0))
    locationFactor = _to_float(locationFactor, 1.0)
    meterFactor = _to_float(meterFactor, 1.0)

    return round(current * locationFactor * meterFactor, 2)


def getEnergyValue(locationFactor=1.0, meterFactor=1.0):
    energy = float(_read("[default]EMS/Energy/Production/Meter_01/EnergyValue", 0))
    locationFactor = _to_float(locationFactor, 1.0)
    meterFactor = _to_float(meterFactor, 1.0)

    return round(energy * locationFactor * meterFactor, 2)


def getVoltage(locationFactor=1.0, meterFactor=1.0):
    locationFactor = _to_float(locationFactor, 1.0)
    meterFactor = _to_float(meterFactor, 1.0)

    voltage = 225.0 + (locationFactor * 8.0) + (meterFactor * 2.0)
    return round(voltage, 2)


def getPowerKw(locationFactor=1.0, meterFactor=1.0):
    current = float(_read("[default]EMS/Energy/Production/Meter_01/Current", 0))
    locationFactor = _to_float(locationFactor, 1.0)
    meterFactor = _to_float(meterFactor, 1.0)

    power_kw = (current * 230.0) / 1000.0
    return round(power_kw * locationFactor * meterFactor, 2)