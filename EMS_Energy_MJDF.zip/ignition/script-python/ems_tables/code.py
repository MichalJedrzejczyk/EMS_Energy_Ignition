def _read(path, default=0):
	try:
		qv = system.tag.readBlocking([path])[0]
		if qv.value is None:
			return default
		return qv.value
	except:
		return default


def _to_float(value, default=1.0):
	try:
		return float(value)
	except:
		return default


def _to_int(value, default=100):
	try:
		return int(value)
	except:
		return default


def _range_factor(rangeValue):
	r = str(rangeValue).lower().replace(" ", "")

	if r in ["last24h", "24h", "last24"]:
		return 1.0

	if r in ["last7d", "7d", "last7days"]:
		return 7.0

	if r in ["last30d", "30d", "last30days"]:
		return 30.0

	return 1.0


def _base_values():
	base_path = "[default]EMS/Energy/Production/Meter_01"

	energy = float(_read(base_path + "/EnergyValue", 0))
	current = float(_read(base_path + "/Current", 0))

	power_kw = (current * 230.0) / 1000.0

	return energy, power_kw


def getEnergyTrendLast24h(rangeValue="Last 24H", displayLimit=100, locationPowerFactor=1.0, locationEnergyFactor=1.0, meterFactor=1.0):
	energy, power = _base_values()

	rangeMultiplier = _range_factor(rangeValue)
	displayLimit = _to_int(displayLimit, 100)

	locationPowerFactor = _to_float(locationPowerFactor, 1.0)
	locationEnergyFactor = _to_float(locationEnergyFactor, 1.0)
	meterFactor = _to_float(meterFactor, 1.0)

	energy = energy * rangeMultiplier * locationEnergyFactor * meterFactor
	power = power * locationPowerFactor * meterFactor

	r = str(rangeValue).lower().replace(" ", "")

	if r in ["last7d", "7d", "last7days"]:
		labels = ["Day -6", "Day -5", "Day -4", "Day -3", "Day -2", "Yesterday", "Today"]
	elif r in ["last30d", "30d", "last30days"]:
		labels = ["D-29", "D-25", "D-21", "D-17", "D-13", "D-9", "D-5", "D-3", "Yesterday", "Today"]
	else:
		labels = ["00h", "03h", "06h", "09h", "12h", "15h", "18h", "21h"]

	rows = []
	count = len(labels)

	for i in range(count):
		progress = float(i + 1) / float(count)
		powerShape = [0.70, 0.85, 0.90, 0.60, 1.00, 0.75, 0.80, 1.00, 0.68, 0.92]

		rows.append({
			"time": labels[i],
			"energy_kwh": round(energy * progress, 2),
			"power_kw": round(power * powerShape[i % len(powerShape)], 2)
		})

	return rows[:displayLimit]


def getConsumptionByLocation(selectedLocation="all", rangeValue="Last 24H", displayLimit=100):
	energy, power = _base_values()

	rangeMultiplier = _range_factor(rangeValue)
	displayLimit = _to_int(displayLimit, 100)

	energy = energy * rangeMultiplier

	allRows = [
		{
			"location": "Production Hall A",
			"max_kw": round(power * 1.00, 2),
			"avg_kw": round(power * 0.65, 2),
			"kwh": round(energy * 1.00, 2)
		},
		{
			"location": "Office",
			"max_kw": round(power * 0.42, 2),
			"avg_kw": round(power * 0.28, 2),
			"kwh": round(energy * 0.36, 2)
		},
		{
			"location": "Server Room",
			"max_kw": round(power * 0.76, 2),
			"avg_kw": round(power * 0.51, 2),
			"kwh": round(energy * 0.58, 2)
		},
		{
			"location": "Main Switchboard",
			"max_kw": round(power * 0.85, 2),
			"avg_kw": round(power * 0.59, 2),
			"kwh": round(energy * 0.78, 2)
		},
		{
			"location": "HVAC Technical",
			"max_kw": round(power * 0.64, 2),
			"avg_kw": round(power * 0.44, 2),
			"kwh": round(energy * 0.49, 2)
		}
	]

	loc = str(selectedLocation)

	if loc == "all":
		return allRows[:displayLimit]

	filterMap = {
		"Production_Hall_A": "Production Hall A",
		"Production Hall A": "Production Hall A",
		"Office": "Office",
		"Server_Room": "Server Room",
		"ServerRoom": "Server Room",
		"Server Room": "Server Room",
		"Main_Switchboard": "Main Switchboard",
		"Main Switchboard": "Main Switchboard",
		"HVAC_Technical": "HVAC Technical",
		"HVAC Technical": "HVAC Technical"
	}

	target = filterMap.get(loc, loc)

	rows = []
	for row in allRows:
		if row["location"] == target:
			rows.append(row)

	return rows[:displayLimit]


def getMeterOverview(selectedMeter="all", rangeValue="Last 24H", displayLimit=100):
	energy, power = _base_values()

	rangeMultiplier = _range_factor(rangeValue)
	displayLimit = _to_int(displayLimit, 100)

	energy = energy * rangeMultiplier

	meters = [
		("Meter_01", "RUN", power * 1.00, energy * 1.00),
		("Meter_02", "RUN", power * 0.84, energy * 0.72),
		("Meter_03", "RUN", power * 0.76, energy * 0.58),
		("Meter_04", "RUN", power * 0.55, energy * 0.44),
		("Meter_05", "RUN", power * 0.68, energy * 0.49),
		("Meter_06", "RUN", power * 0.31, energy * 0.22),
		("Meter_07", "RUN", power * 0.47, energy * 0.35)
	]

	rows = []
	selectedMeter = str(selectedMeter)

	for meter, status, kw, kwh in meters:
		if selectedMeter != "all" and selectedMeter != meter:
			continue

		rows.append({
			"meter": meter,
			"kw": round(kw, 2),
			"kwh": round(kwh, 2),
			"status": status
		})

	return rows[:displayLimit]