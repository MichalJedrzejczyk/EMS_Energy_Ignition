def getKpiCardStyle(value=0, warning=70, critical=90):
	try:
		value = float(value)
	except:
		value = 0

	if value >= critical:
		return {
			"backgroundColor": "#fff1f2",
			"border": "1px solid #ef4444",
			"borderRadius": "12px",
			"boxShadow": "0 4px 12px rgba(239, 68, 68, 0.18)",
			"padding": "12px"
		}

	if value >= warning:
		return {
			"backgroundColor": "#fffbeb",
			"border": "1px solid #f59e0b",
			"borderRadius": "12px",
			"boxShadow": "0 4px 12px rgba(245, 158, 11, 0.18)",
			"padding": "12px"
		}

	return {
		"backgroundColor": "#ffffff",
		"border": "1px solid #e5e7eb",
		"borderRadius": "12px",
		"boxShadow": "0 4px 12px rgba(15, 23, 42, 0.08)",
		"padding": "12px"
	}


def getKpiValueColor(value=0, warning=70, critical=90):
	try:
		value = float(value)
	except:
		value = 0

	if value >= critical:
		return "#dc2626"

	if value >= warning:
		return "#d97706"

	return "#0f172a"


def getAlarmRowStyle(priority="Low", state=""):
	priority = str(priority).lower()
	state = str(state).lower()

	if "critical" in priority or "high" in priority:
		return {
			"backgroundColor": "#fee2e2",
			"color": "#7f1d1d",
			"fontWeight": "600"
		}

	if "medium" in priority:
		return {
			"backgroundColor": "#fef3c7",
			"color": "#78350f",
			"fontWeight": "500"
		}

	if "active" in state:
		return {
			"backgroundColor": "#eff6ff",
			"color": "#1e3a8a"
		}

	return {
		"backgroundColor": "#f8fafc",
		"color": "#334155"
	}


def getStatusColor(status="RUN"):
	status = str(status).upper()

	if status == "RUN":
		return "#16a34a"

	if status == "HIGH":
		return "#dc2626"

	if status == "LOW":
		return "#f59e0b"

	if status == "STOP":
		return "#64748b"

	return "#0f172a"


def getHeaderStyle():
	return {
		"backgroundColor": "#075985",
		"color": "#ffffff",
		"borderRadius": "0px",
		"padding": "8px 12px",
		"boxShadow": "0 2px 8px rgba(15, 23, 42, 0.20)"
	}


def getSectionStyle():
	return {
		"backgroundColor": "#ffffff",
		"border": "1px solid #e5e7eb",
		"borderRadius": "12px",
		"boxShadow": "0 4px 14px rgba(15, 23, 42, 0.08)",
		"padding": "10px",
		"overflow": "hidden"
	}